<?php

class Coba {
	public function __construct() {
		echo "ini adalah kelas Coba";
	}
}